using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlpacaManager : Singleton<AlpacaManager>
{
    // Start is called before the first frame update

    public List<Vector3> levelPositions = new List<Vector3>();
    [SerializeField] GameObject alpacaPrefab;
    public List<GameObject> alpacas = new List<GameObject>();
    public int level = 1;

    void Awake()
    {
        //spawnAlpacas(level);
        printVectors();


    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public static Vector3 getVector(float x, float y, float z)
    {
        return new Vector3(x, y, z);
    }

    public void setLevelPositions(int level)
    {
        levelPositions = new List<Vector3>();
        switch (level)
        {//debug
            case 0:
                levelPositions.Add(getVector(0f, 0f, 0f));
                break;
            //level 1 positions
            case 1:
                levelPositions.Add(getVector(-8.5f, 3.5f, 0f));
                levelPositions.Add(getVector(-6.5f, 3.5f, 0f));
                levelPositions.Add(getVector(-4.5f, 3.5f, 0f));
                levelPositions.Add(getVector(-2.5f, 3.5f, 0f));
                levelPositions.Add(getVector(0f, 3.5f, 0f));
                levelPositions.Add(getVector(2.5f, 3.5f, 0f));
                levelPositions.Add(getVector(4.5f, 3.5f, 0f));
                levelPositions.Add(getVector(6.5f, 3.5f, 0f));
                levelPositions.Add(getVector(8.5f, 3.5f, 0f));
                levelPositions.Add(getVector(-7.5f, 2.5f, 0f));
                levelPositions.Add(getVector(-5.5f, 2.5f, 0f));
                levelPositions.Add(getVector(-3.5f, 2.5f, 0f));
                levelPositions.Add(getVector(-1.5f, 2.5f, 0f));
                levelPositions.Add(getVector(1.5f, 2.5f, 0f));
                levelPositions.Add(getVector(3.5f, 2.5f, 0f));
                levelPositions.Add(getVector(5.5f, 2.5f, 0f));
                levelPositions.Add(getVector(7.5f, 2.5f, 0f));
                break;
            case 2:
                levelPositions.Add(getVector(-6f, 3.5f, 0f));
                levelPositions.Add(getVector(-4f, 3.5f, 0f));
                levelPositions.Add(getVector(-2f, 3.5f, 0f));
                levelPositions.Add(getVector(2f, 3.5f, 0f));
                levelPositions.Add(getVector(4f, 3.5f, 0f));
                levelPositions.Add(getVector(6f, 3.5f, 0f));
                levelPositions.Add(getVector(-8f, 2.5f, 0f));
                levelPositions.Add(getVector(0f, 2.5f, 0f));
                levelPositions.Add(getVector(8f, 2.5f, 0f));
                levelPositions.Add(getVector(-5f, 2f, 0f));
                levelPositions.Add(getVector(-3f, 2f, 0f));
                levelPositions.Add(getVector(3f, 2f, 0f));
                levelPositions.Add(getVector(5f, 2f, 0f));
                levelPositions.Add(getVector(-4f, 0.5f, 0f));
                levelPositions.Add(getVector(4f, 0.5f, 0f));
                break;
            case 3:
                levelPositions.Add(getVector(0f, 2.5f, 0f));
            break;
            case 4:
                levelPositions.Add(getVector(2.5f, -1f, 0f));
                levelPositions.Add(getVector(0f, 4f, 0f));
                levelPositions.Add(getVector(0f, 1.45f, 0f));
                levelPositions.Add(getVector(0f, 0f, 0f));
                levelPositions.Add(getVector(-3f, 2.5f, 0f));
                levelPositions.Add(getVector(-1f, 2.5f, 0f));
                levelPositions.Add(getVector(1f, 2.5f, 0f));
                levelPositions.Add(getVector(3f, 2.5f, 0f));
                levelPositions.Add(getVector(-2f, 1f, 0f));
                levelPositions.Add(getVector(2f, 1f, 0f));
                levelPositions.Add(getVector(-2.5f, -1f, 0f));

                break;
            case 5:
                levelPositions.Add(getVector(0f, 3f, 0f));
                levelPositions.Add(getVector(0f, -1f, 0f));
                levelPositions.Add(getVector(-1.5f, 0f, 0f));
                levelPositions.Add(getVector(1.5f, 0f, 0f));
                levelPositions.Add(getVector(-2.5f, 0.5f, 0f));
                levelPositions.Add(getVector(2.5f, 0.5f, 0f));
                levelPositions.Add(getVector(-3.5f, 1.5f, 0f));
                levelPositions.Add(getVector(3.5f, 1.5f, 0f));
                levelPositions.Add(getVector(-4f, 3f, 0f));
                levelPositions.Add(getVector(4f, 3f, 0f));
                levelPositions.Add(getVector(-3f, 4.25f, 0f));
                levelPositions.Add(getVector(3f, 4.25f, 0f));
                levelPositions.Add(getVector(-1.5f, 3.75f, 0f));
                levelPositions.Add(getVector(1.5f, 3.75f, 0f));
                break;
            case 6:
                levelPositions.Add(getVector(0f, 2.5f, 0f));
            break;
            case 7:
                levelPositions.Add(getVector(4.5f, 1.5f, 0f));
                levelPositions.Add(getVector(5.5f, 3f, 0f));
                levelPositions.Add(getVector(4f, 3f, 0f));
                levelPositions.Add(getVector(7f, 2f, 0f));
                levelPositions.Add(getVector(7f, 3f, 0f));
                levelPositions.Add(getVector(7f, 4f, 0f));
                levelPositions.Add(getVector(7f, 0f, 0f));
                levelPositions.Add(getVector(2.5f, 4f, 0f));
                levelPositions.Add(getVector(2.5f, 3f, 0f));
                levelPositions.Add(getVector(2.5f, 1f, 0f));
                levelPositions.Add(getVector(2.5f, 0f, 0f));
                levelPositions.Add(getVector(-4.5f, 2f, 0f));
                levelPositions.Add(getVector(-4.5f, 4f, 0f));
                levelPositions.Add(getVector(-4.5f, 0f, 0f));
                levelPositions.Add(getVector(-6f, 0f, 0f));
                levelPositions.Add(getVector(-3f, 0f, 0f));
                levelPositions.Add(getVector(-2f, 0f, 0f));
                levelPositions.Add(getVector(-3f, 2f, 0f));
                levelPositions.Add(getVector(-6f, 2f, 0f));
                levelPositions.Add(getVector(-7f, 3f, 0f));
                levelPositions.Add(getVector(-5.5f, 4f, 0f));
                levelPositions.Add(getVector(-3.5f, 4f, 0f));
                
                break;
            case 8:
                levelPositions.Add(getVector(8f,2.5f,0f));
                levelPositions.Add(getVector(4f, 2.5f, 0f));
                levelPositions.Add(getVector(-9f, 2.5f, 0f));
                levelPositions.Add(getVector(-6f, 2.5f, 0f));
                levelPositions.Add(getVector(1f, 0f, 0f));
                levelPositions.Add(getVector(0f, 1f, 0f));
                levelPositions.Add(getVector(0f, 2.5f, 0f));
                levelPositions.Add(getVector(0f, 3f, 0f));
                levelPositions.Add(getVector(0f, 4f, 0f));
                levelPositions.Add(getVector(-2.5f, 4f, 0f));
                levelPositions.Add(getVector(-2.5f, 2f, 0f));
                levelPositions.Add(getVector(-2.5f, 0.5f, 0f));
                
                break;
            // case 6:
            //     levelPositions.Add(getVector(-10f, 3.5f, 0f));
            //     levelPositions.Add(getVector(-4f, 3.5f, 0f));
            //     levelPositions.Add(getVector(4f, 3.5f, 0f));
            //     levelPositions.Add(getVector(10f, 3.5f, 0f));
            //     levelPositions.Add(getVector(-7.5f, 2.5f, 0f));
            //     levelPositions.Add(getVector(-5.5f, 1.5f, 0f));
            //     levelPositions.Add(getVector(-2.5f, 0.5f, 0f));
            //     levelPositions.Add(getVector(0f, -0.5f, 0f));
            //     levelPositions.Add(getVector(2.5f, 0.5f, 0f));
            //     levelPositions.Add(getVector(5.5f, 1.5f, 0f));
            //     levelPositions.Add(getVector(7.5f, 2.5f, 0f));
            //     break;
            // case 3:
            //     levelPositions.Add(getVector(-10f, 3.5f, 0f));
            //     levelPositions.Add(getVector(-4f, 3.5f, 0f));
            //     levelPositions.Add(getVector(4f, 3.5f, 0f));
            //     levelPositions.Add(getVector(10f, 3.5f, 0f));
            //     levelPositions.Add(getVector(-7.5f, 2.5f, 0f));
            //     levelPositions.Add(getVector(-5.5f, 1.5f, 0f));
            //     levelPositions.Add(getVector(-2.5f, 0.5f, 0f));
            //     levelPositions.Add(getVector(0f, -0.5f, 0f));
            //     levelPositions.Add(getVector(2.5f, 0.5f, 0f));
            //     levelPositions.Add(getVector(5.5f, 1.5f, 0f));
            //     levelPositions.Add(getVector(7.5f, 2.5f, 0f));
            //     break;
             case 9:
                 levelPositions.Add(getVector(0f, 2.5f, 0f));
                 levelPositions.Add(getVector(1f, 2.5f, 0f));
                 levelPositions.Add(getVector(2.5f, -0.5f, 0f));
                 levelPositions.Add(getVector(2.5f, 0.5f, 0f));
                 levelPositions.Add(getVector(2.5f, 2f, 0f));
                 levelPositions.Add(getVector(3f, 3f, 0f));
                 levelPositions.Add(getVector(2f, 4f, 0f));
                 levelPositions.Add(getVector(0f, 4.5f, 0f));
                 levelPositions.Add(getVector(-1f, 4.5f, 0f));
                 levelPositions.Add(getVector(-2.5f, 4.5f, 0f));
                 levelPositions.Add(getVector(-3.5f, 3f, 0f));
                 levelPositions.Add(getVector(-3.5f, 1f, 0f));
                 levelPositions.Add(getVector(-3.5f, -0.5f, 0f));
                 break;
             //case 10:
             //    levelPositions.Add(getVector(-9.4f, 4.2f, 0f));
             //    levelPositions.Add(getVector(-8.8f, 2.8f, 0f));
             //    levelPositions.Add(getVector(-7.8f, 1.5f, 0f));
              //   levelPositions.Add(getVector(-6.6f, 0.4f, 0f));
             //    levelPositions.Add(getVector(-5.1f, -0.4f, 0f));
             //    levelPositions.Add(getVector(-3.4f, -0.7f, 0f));
             //    levelPositions.Add(getVector(-1.8f, -1.0f, 0f));
             //    levelPositions.Add(getVector(0f, 1.2f, 0f));
             //    levelPositions.Add(getVector(9.4f, 4.2f, 0f));
              //   levelPositions.Add(getVector(8.8f, 2.8f, 0f));
             //    levelPositions.Add(getVector(7.8f, 1.5f, 0f));
             //    levelPositions.Add(getVector(6.6f, 0.4f, 0f));
             //    levelPositions.Add(getVector(5.1f, -0.4f, 0f));
             //    levelPositions.Add(getVector(3.4f, -0.7f, 0f));
             //    levelPositions.Add(getVector(1.8f, -1.0f, 0f));


            //     break;
            case 10:
                levelPositions.Add(getVector(0f, 2.5f, 0f));
                
                levelPositions.Add(getVector(-5f, 2.5f, 0f));
                
                levelPositions.Add(getVector(5f, 2.5f, 0f));
                break;
            default:
                Debug.Log("Not an octopus.");
                break;

        }    
                
        
        
    }
    

    public void spawnAlpacas(int level)
    {
        setLevelPositions(level);
        Debug.Log("spawning in " + levelPositions.Count + " alpacas");
        switch(level){
            case 0:
            case 1:
        foreach (Vector3 v in levelPositions) {
            alpacaPrefab.transform.position = v;
            GameObject a = Instantiate(alpacaPrefab);
            a.GetComponent<AlpacaBehavior>().type = 0;
            alpacas.Add(a);
            // Debug.Log(a.transform.position);
        }
            break;
            case 2:
            foreach (Vector3 v in levelPositions) {
            alpacaPrefab.transform.position = v;
            GameObject a = Instantiate(alpacaPrefab);
            if(v == getVector(-8f, 2.5f, 0f) || v == getVector(0f, 2.5f, 0f) ||v == getVector(8f, 2.5f, 0f)){

            a.GetComponent<AlpacaBehavior>().type = 3;
            }else{
                a.GetComponent<AlpacaBehavior>().type = 0;
            }
                
            alpacas.Add(a);
            // Debug.Log(a.transform.position);
        }
            break;
            case 3:

            foreach (Vector3 v in levelPositions) {
            alpacaPrefab.transform.position = v;
            GameObject a = Instantiate(alpacaPrefab);
            a.GetComponent<AlpacaBehavior>().type = 4;
            alpacas.Add(a);
            // Debug.Log(a.transform.position);
            }
            break;
        case 6:
            foreach (Vector3 v in levelPositions) {
            alpacaPrefab.transform.position = v;
            GameObject a = Instantiate(alpacaPrefab);
            a.GetComponent<AlpacaBehavior>().type = 5;
            alpacas.Add(a);
            // Debug.Log(a.transform.position);
        }
        break;
        case 10:
            foreach (Vector3 v in levelPositions) {
            alpacaPrefab.transform.position = v;
            GameObject a = Instantiate(alpacaPrefab);
            a.GetComponent<AlpacaBehavior>().type = 6;
            alpacas.Add(a);
            // Debug.Log(a.transform.position);
        }
        break;
    
            case 4:
            case 5:
            
            case 7:
            case 8:
            case 9:
            
            

                foreach (Vector3 v in levelPositions)
                {
                    alpacaPrefab.transform.position = v;
                    GameObject a = Instantiate(alpacaPrefab);
                    a.GetComponent<AlpacaBehavior>().type = 0;
                    alpacas.Add(a);
                    // Debug.Log(a.transform.position);
                }
                break;

        }
        //levelPositions.RemoveAt(levelPositions.Count - 1);
        //levelPositions = new List<Vector3>();
    }

    public void removeAlpaca(GameObject thing)
    {
        alpacas.Remove(thing);
        //levelPositions.Remove(thing.transform.position);
        Destroy(thing);
    }

    public void printVectors()
    {
        GameObject[] a = GameObject.FindGameObjectsWithTag("Enemy");
        foreach(GameObject o in a ) {
            Debug.Log(o.transform.position);
        }
    }
}
