using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletBehavior : MonoBehaviour
{
    // Start is called before the first frame update
    public int bulletType = 0;
    //0 is default
    //1 is spiral
    //2 is homing
    //3 is player bullet
    //4 is diagonal
    //5 is diagonal but different direction
    public bool isPlayer = false;
    public float bulletLife = 10f; //so we dont lag
    public float speed = 1f;

    private float timer = 0f;
    
private SpriteRenderer spriteRenderer;  
public Sprite[] bulletSprites;

    void Start()
    {
        // switch(bulletType){
        //     case 0:
        // }
        
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        if(bulletType > bulletSprites.Length-1){
        spriteRenderer.sprite = bulletSprites[0];
        }else{
        spriteRenderer.sprite = bulletSprites[bulletType];
        }
EventBus.Subscribe(EventBus.EventType.TimeUp, Die);
EventBus.Subscribe(EventBus.EventType.WaveCleared, Die);
    }
private float spiralAngle = 0f;

    // Update is called once per frame
    void FixedUpdate()//every X seconds, it is called regardless of frames
    {

        timer += Time.deltaTime;
        if(!isPlayer){
            switch(bulletType){
                case 0:
        transform.Translate(Vector3.down * speed / 10) ; //how to translate direction
                break;
                case 1:
                // float spiralX = (Mathf.Sin(spiralAngle*Mathf.PI*speed)/180f);
                // float spiralY = (Mathf.Cos(spiralAngle*Mathf.PI*speed)/180f);
                // Debug.LogFormat("X pos? {0}", spiralX);
                // Debug.LogFormat("Y pos? {0}", spiralY);
                // Vector3 moveSpiral = new Vector3(spiralX, spiralY, 0f);
                // transform.position += moveSpiral;// always want to add .5f
                
                transform.position = new Vector3(transform.position.x + Mathf.Sin(transform.position.y*2)*(speed / 10), transform.position.y -(speed / 10), transform.position.z);
                //force forward
                spiralAngle += 10f;
                break;
                case 2:
        transform.Translate(Vector3.down * speed / 10) ; //how to translate direction
                break;
                case 4:
                transform.position = new Vector3(transform.position.x +(speed / 10), transform.position.y -(speed / 10), transform.position.z);
                break;
                case 5:
                transform.position = new Vector3(transform.position.x -(speed / 10), transform.position.y - (speed / 10), transform.position.z);
                break;
            }
        }else{
            Debug.Log("Player shoots");
        transform.Translate(Vector3.up * speed / 10); //how to translate direction  
        }
        if(transform.position.y > 5 || transform.position.y < -5 ||transform.position.x > 11 || transform.position.x < -11 || timer > bulletLife){//no collision for now
            Die();
        }
            // gameObject.SendMessage("SetCount", null, SendMessageOptions.DontRequireReceiver);
        
    }

  





    public void Die(){
        
EventBus.Unsubscribe(EventBus.EventType.TimeUp, Die);
EventBus.Unsubscribe(EventBus.EventType.WaveCleared, Die);
Destroy(gameObject);
    }
}
