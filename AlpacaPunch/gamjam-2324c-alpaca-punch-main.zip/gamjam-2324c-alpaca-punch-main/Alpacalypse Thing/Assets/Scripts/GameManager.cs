using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : Singleton<GameManager>
{
    string[] level = new[] { "TitleScreen", "MainScreen", "SettingsScreen", "GameOverScreen" };
    public int levelID = 1;
    public float timeElapsed = 0.0f;
    public float timer = 30f;//i will probably reuse some code i have from my own game jam from earlier
    public bool changing;   
   public bool isMouseControlled = false;//else, use WASD
    public int wavesCleared = 0;
    public bool isInMain = false;
    Scene m_Scene;
 string sceneName;

    // Start is called before the first frame update
//timer functions will go in here, so will generating the levels and keeping track of beaten levels already
//reset timer every level either you time out or you kill all alpacas
//list of alpacas spawned from alpaca manager, then check the status of list, if empty, it'll publish an event to proceed to next level.
//level count is static. level layout is also static, comes from list.
//check index of listS
//mini boss level is 60. average is 30. boss has no time limit.
    void Start()
    {
        timeElapsed = timer;
        // if(isInMain){
        // AlpacaManager.Instance.spawnAlpacas(levelID);
        // startLevel();
        // Debug.LogFormat("Level 1: there are {0} alpacas", AlpacaManager.Instance.alpacas.Count);
        // }
        levelID = 0;
        wavesCleared = 0;
        EventBus.Subscribe(EventBus.EventType.GameOver, LoadGameOverScreen);
        EventBus.Subscribe(EventBus.EventType.ResetGame, Reset);
        //start the timer
        
    }

    // Update is called once per frame
    void Update()
    {
        
        if(isInMain){
        timeElapsed -= Time.deltaTime;
        Debug.LogFormat("There are {0} alpacas", AlpacaManager.Instance.alpacas.Count);
        if(AlpacaManager.Instance.alpacas.Count == 0 && levelID < 11 && !changing){
            changing = true;
            Invoke("startLevel", 1f); 
            
            // levelID++;     
            // wavesCleared++;     
EventBus.Publish(EventBus.EventType.WaveCleared);
        }
        if(timeElapsed <= 0.0f ){
           changing = true;
            Invoke("startLevel", 1f);   
            timeElapsed = timer;
            
            // levelID++;     
            // wavesCleared++;     
            
EventBus.Publish(EventBus.EventType.WaveCleared);
EventBus.Publish(EventBus.EventType.TimeUp);
        }
        }
        //this is timer stuff
        /*
        
        if(timeElapsed<=0.0f || alpaca crap is cleared out){
        EventBus.Publish(EventBus.EventType.TimeUp);//do we want to use events for this thing???
            StartCoroutine(GameOverCoroutine());
            reset some variables or somethings
            hasUsedSummon = false;
        }
        */
        //if level, then trigger
        //if level == 10, then go to ending if in story mode
        //check if level is cleared or if time is up, then go to next level, and reset the timer
    }

    

    public void startLevel()
    {
        isInMain = true;
        // wavesCleared--;
            Debug.Log("Ping pong! Next Level!");
            nextLevel();
        //display text, maybe spawn some shit
        
        
        Debug.Log("Level is now " +  levelID);
    AlpacaManager.Instance.spawnAlpacas(levelID);
        switch(levelID){
            case 1:
            case 2:
            case 4:
            case 5:
            case 7:
            case 8:
                timer = 30f;
                break;
            case 3:
            case 6:
            case 9:
                timer = 60f;
                break;
            case 10:
                timer = 300f;//you should be more than equipped to kill the boss within this time limit
                break;
            default:
                timer = 1000000000f;//more than enough time to debug lmao
                break;
        }
        timeElapsed = timer;
        changing = false;
        return;
        // Reset();//reload everything to avoid between-game data leakage
    }

    public void nextLevel()
    {
        isInMain = true;
        levelID += 1;
        wavesCleared++;
        if(levelID > 10){
            LoadGameOverScreen();
        }
        Debug.Log("Level increased!");
    }
      public void LoadTitleScreen()
    {
        isInMain = false;
        // levelID = 1;
        SceneManager.LoadScene("TitleScreen");
    }
      public void LoadGameOverScreen()
    {
        isInMain = false;
        wavesCleared--;
        SceneManager.LoadScene("GameOverScreen");
        
    AudioManager.Instance.Play("game_over");
    }
    void Reset(){
        levelID = 0;
        wavesCleared = 0;
    }

}
