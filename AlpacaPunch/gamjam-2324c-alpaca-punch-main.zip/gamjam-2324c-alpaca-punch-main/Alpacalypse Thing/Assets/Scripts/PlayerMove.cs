using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{

    Rigidbody2D body;
    CapsuleCollider2D collider;
    float speed = 5f;
    float bulletTimer = 1f;
    // Start is called before the first frame update
    void Awake()
    {
    body = GetComponent<Rigidbody2D>();
    collider = GetComponent<CapsuleCollider2D>();
        
    }

    // Update is called once per frame
    void Update()
    {
        if(GameManager.Instance.isMouseControlled){//https://gamedevbeginner.com/make-an-object-follow-the-mouse-in-unity-in-2d/
Vector3 mousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePosition.z = Camera.main.transform.position.z + Camera.main.nearClipPlane;
        transform.position = mousePosition;
        }else{
        float deltaX = Input.GetAxis("Horizontal") * speed;
        float deltaY = Input.GetAxis("Vertical") * speed;
        Vector2 movement = new Vector2(deltaX, deltaY);
        body.velocity = movement;
        }
        Vector3 pos = transform.position;//for handling out of bounds
        if(pos.y < -5f){
            pos.y = -5f;
            transform.position = pos;
        }
        if(pos.y > 5f){
            pos.y = 5f;
            transform.position = pos;
        }
        if(pos.x > 11f){
            pos.x = 11f;
            transform.position = pos;
        }
        if(pos.x < -11f){
            pos.x = -11f;
            transform.position = pos;
        }
        
        if(Input.GetKey(KeyCode.Space)){
            Shoot(true);
        AudioManager.Instance.Play("shoot");
        }
        if(Input.GetKeyUp(KeyCode.Space)){
            Shoot(false);
        }
        //get key down
//
        
    }
    
    void Shoot(bool isPressed){
        Vector3 bulletPos = gameObject.transform.position;
        
        bulletPos.y += 1;
if(isPressed){

bulletTimer -= 1 * Time.deltaTime;
        if(bulletTimer <= 0)
        {
            bulletTimer = 1f;
        BulletManager.Instance.SpawnBullet(bulletPos, 3, true);
        }
//every X seconds, fire bullet(s) depending on behavior
            
}else{
        BulletManager.Instance.SpawnBullet(bulletPos, 3, true);
}
    }
}
