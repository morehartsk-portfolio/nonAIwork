using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToggleControls : MonoBehaviour
{
    // Start is called before the first frame update
    public void UseMouse()
    {
        GameManager.Instance.isMouseControlled = !GameManager.Instance.isMouseControlled;
    }
      public void LoadTitleScreen()
    {
        GameManager.Instance.LoadTitleScreen();
    }
}
