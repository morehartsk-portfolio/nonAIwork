using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TextUpdate : MonoBehaviour
{
    TMP_Text text;
    enum Field { GameOverText, WaveClearedText};

    [SerializeField] Field field = Field.GameOverText;
    // Start is called before the first frame update
    void Start()
    {
         text = GetComponent<TMP_Text>();
EventBus.Subscribe(EventBus.EventType.WaveCleared, SetText);
       SetText();
        
    }

    // Update is called once per frame
    void SetText()
    {
if (field == Field.GameOverText)
        {
            text.text = "You cleared " + GameManager.Instance.wavesCleared + " waves.";
            // text.text = "Gold: " + GameManager.Instance.ToString();
        }
if (field == Field.WaveClearedText)
        {
            text.text = "Waves: " + GameManager.Instance.wavesCleared;
            // text.text = "Gold: " + GameManager.Instance.ToString();
        }
    }
}
