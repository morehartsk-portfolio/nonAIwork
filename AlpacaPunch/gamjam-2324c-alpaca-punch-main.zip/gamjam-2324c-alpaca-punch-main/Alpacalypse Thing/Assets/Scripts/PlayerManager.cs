using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerManager : Singleton<PlayerManager>
{
    // Start is called before the first frame update
    public int lives = 5;
[SerializeField] GameObject playerPrefab; 
    GameObject _player = null;//if null, it vanishes
    //see in class example for multiple lives
    void Awake()
    {
     lives = 5;   
        SpawnPlayer();
        EventBus.Subscribe(EventBus.EventType.PlayerHurt, DamagePlayer);
    }

    // Update is called once per frame
    void Update()
    {

    }
void SpawnPlayer(){
    // lives--;
    if(lives > 0){
            _player = Instantiate(playerPrefab);
            _player.transform.position = new Vector3(0, -4.5f, 0);
        }else{
            
EventBus.Publish(EventBus.EventType.GameOver);
        }
}
void DamagePlayer(){
    lives--;
    if(lives > 0){
    AudioManager.Instance.Play("hurt");
    }
    SpawnPlayer();
}
    
}
