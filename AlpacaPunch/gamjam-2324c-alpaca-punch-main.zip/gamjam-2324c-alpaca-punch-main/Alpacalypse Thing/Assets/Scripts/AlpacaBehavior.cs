using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AlpacaBehavior : MonoBehaviour
{
    //[SerializeField] GameObject bulletPrefab;
    float bulletTimer;
    CapsuleCollider2D collider;
    Rigidbody2D body;
    float bulletRate = 2f;
    public int type = 0; //0 = type 1, type 2, type 3
    //type one does normal bullet
    //type 3 does homing bullet
    //type 2 does array of bullets
    //type 4 sine wave
    // type 5 should be a boss
    public int hitCounter = 0; //hit counter for bosses

private SpriteRenderer spriteRenderer;
public Sprite[] alpacaSprites;

    //insert types here. we have 3 types of bullet patterns which will determine behavior.
    // Start is called before the first frame update
    void Start()
    {
        collider = GetComponent<CapsuleCollider2D>();
        body = GetComponent<Rigidbody2D>();
        bulletTimer = Random.Range(0f, bulletRate);
        spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
        spriteRenderer.sprite = alpacaSprites[1];
        if(type > alpacaSprites.Length - 1){
            if(type == 4){
                        gameObject.transform.localScale += new Vector3(5,5,0);
                        
        spriteRenderer.sprite = alpacaSprites[0];
            }
            if(type == 5){
                
                        gameObject.transform.localScale += new Vector3(5,5,0);
                        
        spriteRenderer.sprite = alpacaSprites[1];
            }
            if(type == 6){
                
                        gameObject.transform.localScale += new Vector3(5,5,0);
                        
        spriteRenderer.sprite = alpacaSprites[2];
            }
            
        }else{
        spriteRenderer.sprite = alpacaSprites[type];
        }
        //depending on type we should despawn the hell

EventBus.Subscribe(EventBus.EventType.TimeUp, Die);
    }

    // Update is called once per frame
    void Update()
    {
        bulletTimer -= 1 * Time.deltaTime;
        if(bulletTimer <= 0)
        {
            bulletTimer = bulletRate;
            Shoot();
        }

        
    }
    void Die(){
        //when dies, or when time runs out, die.
Debug.Log("Died");
EventBus.Unsubscribe(EventBus.EventType.TimeUp, Die);
        AlpacaManager.Instance.removeAlpaca(gameObject);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log("test");
        string colliderInfo = collision.collider.tag;
        BulletBehavior obj = collision.gameObject.GetComponent<BulletBehavior>();
        if(obj.isPlayer)
        {
            if(type < 4){
            Die();

            }else{
            hitCounter++;
            
                if(hitCounter == 3){
                    hitCounter = 0;
                    Die();
                }
            }
            Destroy(collision.gameObject);
        }else{
            Physics2D.IgnoreCollision(obj.GetComponent<Collider2D>(), GetComponent<Collider2D>());
        }

    }

    void Shoot(){
//every X seconds, fire bullet(s) depending on behavior
        Vector3 bulletPos = gameObject.transform.position;
        bulletPos.y -= 1;
        switch(type){
            case 0:
        BulletManager.Instance.SpawnBullet(bulletPos, 0, false);
        break;
            case 1:
        BulletManager.Instance.SpawnBullet(bulletPos, 0, false);
        BulletManager.Instance.SpawnBullet(bulletPos, 4, false);
        BulletManager.Instance.SpawnBullet(bulletPos, 5, false);
            break;
            case 2:
        BulletManager.Instance.SpawnBullet(bulletPos, 2, false);
        break;
            case 3:
        BulletManager.Instance.SpawnBullet(bulletPos, 1, false);
        break;
            case 4:
        BulletManager.Instance.SpawnBullet(bulletPos, 0, false);
        bulletPos.x -= 3;
        BulletManager.Instance.SpawnBullet(bulletPos, 0, false);
        bulletPos.x += 6;
        BulletManager.Instance.SpawnBullet(bulletPos, 0, false);
        break;
            case 5:
        BulletManager.Instance.SpawnBullet(bulletPos, 1, false);
        bulletPos.x -= 3;
        BulletManager.Instance.SpawnBullet(bulletPos, 1, false);
        bulletPos.x += 6;
        BulletManager.Instance.SpawnBullet(bulletPos, 1, false);
        break;
            case 6:

        BulletManager.Instance.SpawnBullet(bulletPos, 0, false);
        BulletManager.Instance.SpawnBullet(bulletPos, 4, false);
        BulletManager.Instance.SpawnBullet(bulletPos, 5, false);
        bulletPos.x -= 3;

        BulletManager.Instance.SpawnBullet(bulletPos, 0, false);
        BulletManager.Instance.SpawnBullet(bulletPos, 4, false);
        BulletManager.Instance.SpawnBullet(bulletPos, 5, false);
        bulletPos.x += 6;
        BulletManager.Instance.SpawnBullet(bulletPos, 0, false);
        BulletManager.Instance.SpawnBullet(bulletPos, 4, false);
        BulletManager.Instance.SpawnBullet(bulletPos, 5, false);
        break;
        }
            
    }

}
