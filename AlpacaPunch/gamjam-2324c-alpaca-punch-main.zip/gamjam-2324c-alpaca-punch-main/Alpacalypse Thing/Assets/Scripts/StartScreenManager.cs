using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class StartScreenManager : MonoBehaviour
{
    // Start is called before the first frame update\
    




    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void LoadStoryModeScreen()
    {
        
        GameManager.Instance.isInMain = true;
        
EventBus.Publish(EventBus.EventType.ResetGame);
        SceneManager.LoadScene("MainScreen");
    }

    public void LoadHowToPlayScreen()
    {
        SceneManager.LoadScene("HowToPlayScreen");
    }

    public void LoadEndlessModeScreen()
    {
        //SceneManager.LoadScene("HowToPlayScreen");
    }

    public void LoadCreditsScreen()
    {
        SceneManager.LoadScene("CreditsScreen");
    }
        
    public void LoadSettingsScreen()
    {
        SceneManager.LoadScene("SettingsScreen");
    }







}
