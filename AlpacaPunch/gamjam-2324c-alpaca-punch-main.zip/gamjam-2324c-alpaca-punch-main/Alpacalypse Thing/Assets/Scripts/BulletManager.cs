using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//check to see who is firing a command, then spawn bullet at location, then bullet behavior depends on whoever called it. player bullets move up, enemy bullets move down
//should not hurt whoever fired it/allies
public class BulletManager : Singleton<BulletManager>
{
    // Start is called before the first frame update
    //list of bullets
    //bullets last for 5 seconds or 
    [SerializeField] GameObject bulletPrefab;
//https://www.youtube.com/watch?v=YNJM7rWbbxY

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }//check for collision
    
    public void SpawnBullet(Vector3 pos, int type, bool isPlayer)
    {
        GameObject b = Instantiate(bulletPrefab);//vector3 is immutable, position is vector3
        b.transform.position = pos;
        b.GetComponent<BulletBehavior>().isPlayer = isPlayer;
        b.GetComponent<BulletBehavior>().bulletType = type;
        //isPlayer will determine how it 
        
    }
}
