using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    // [SerializeField] GameObject gameOverScreen;


    [SerializeField] GameObject life1;
    [SerializeField] GameObject life2;
    [SerializeField] GameObject life3;
    [SerializeField] GameObject life4;
    [SerializeField] GameObject life5;

    // Start is called before the first frame update
    void Start()
    {
        // GameManager.Instance.SetGameOverScreen(gameOverScreen);
        EventBus.Subscribe(EventBus.EventType.PlayerHurt, UpdateLives);
        UpdateLives();
    }

    void UpdateLives()
    {
        life1.SetActive(false);
        life2.SetActive(false);
        life3.SetActive(false);
        life4.SetActive(false);
        life5.SetActive(false);

        if (PlayerManager.Instance.lives >= 1)
        {
            life1.SetActive(true);
        }
        if(PlayerManager.Instance.lives >= 2)
        {
            life2.SetActive(true);

        }
        if (PlayerManager.Instance.lives >= 3)
        {
            life3.SetActive(true);
        }
        if (PlayerManager.Instance.lives >= 4)
        {
            life4.SetActive(true);
        }
        if (PlayerManager.Instance.lives >= 5)
        {
            life5.SetActive(true);
        }
    }


}
