using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInfo : MonoBehaviour
{
    //keep track of lives
    //start off with 3
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnCollisionEnter2D(Collision2D collision){

        BulletBehavior obj = collision.gameObject.GetComponent<BulletBehavior>();
        if(!obj.isPlayer)
        {
            
EventBus.Publish(EventBus.EventType.PlayerHurt);
            Destroy(gameObject);
            Destroy(collision.gameObject);
        }


        //this is for handling collisions 
        // Debug.Log("A collision happened");
        string colliderInfo = collision.collider.tag; //get info on first collider
        //check if a collision actually occurred, then take the tags and compare!
        if(colliderInfo != null){
        // pinfo.Die();
        ContactPoint2D[] contactPoints = new ContactPoint2D[5];
        collision.GetContacts(contactPoints);
        // Debug.LogFormat("{0}", contactPoints[0].normal);

        /**
        if(contactPoints[0].normal.y != null){
            
                //Debug.Log(colliderInfo);
                //idk how we handle this
                
        } **/

        }
}
}
