USE NWindmorehask
Go

SELECT c.CompanyName, c.ContactName
FROM  Customers AS c 
WHERE NOT EXISTS(SELECT o.OrderID
FROM Orders AS o
WHERE o.CustomerID = c.CustomerID)
ORDER BY c.CompanyName
--This query works by searching through the Orders data and comparing it with the customer data.
--Then it removes all the results that appear in both tables, leaving us with customers without any orders.

SELECT c.CompanyName, c.ContactName
FROM  Customers AS c LEFT JOIN Orders AS o ON o.CustomerID = c.CustomerID
WHERE o.OrderID IS NULL
ORDER BY c.CompanyName
--A left join will fill in any unmatched values in Customers with NULL values. We then search the joined table for null values at a specified column.

--The Join method is better here, since instead of searching through two separate tables, we combine them and search through one for a specific value, NULL.
--In the EXISTS method, we'd need to comb through two separate tables in order to find the differences to display. This is slower and more complicated.
--I don't know if SQL has a way of showing how long it took to execute a query, but I'm certain there's a substantial time difference between the two methods.