USE NWindmorehask
Go

SELECT c.CategoryID, c.CategoryName, ROUND(AVG(p.UnitPrice),2) AS AveragePrice
FROM Categories AS c JOIN Products AS p ON c.CategoryID = p.CategoryID
--Products and Categories both have a CategoryID attribute, so if we use that to join the two tables, it should be easier to organize.
--By doing so, I've also made it easier to calculate the average of each category.
--GroupBy is to sort the tuples from our new table.
GROUP BY c.CategoryID, c.CategoryName
-- HAVING is used where a WHERE clause would fail. in this case, when there's an inequality to solve for.
HAVING AVG(p.UnitPrice) > 25
--this was the filter that was missing initially. While WHERE is for equalities, this isn't something WHERE can solve.
ORDER BY AveragePrice DESC