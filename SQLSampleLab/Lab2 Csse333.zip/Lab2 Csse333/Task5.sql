USE NWindmorehask
Go
--SELECT Orders.OrderID, Quantity, OrderDate, Orders.CustomerID,ContactName
--the beta version of the final command ^
SELECT od.OrderID, o.OrderDate, c.CompanyName, c.ContactName, SUM(od.Quantity) AS TotalQuantity
--using sum to get total quantity for all individual products in each order. also, needed to find the company details using ID.
FROM [Order Details] AS od JOIN Orders AS o ON od.OrderID = o.OrderID JOIN Customers AS c ON o.CustomerID = c.CustomerID
--Each order has an order ID that corresponds to Order Details. Order will also include a customer ID which corresponds to a company. each company has
GROUP BY od.OrderID, o.OrderDate,c.CompanyName,c.ContactName
--Must include other attributes in group by, not just the one you're grouping!
ORDER BY od.OrderID ASC