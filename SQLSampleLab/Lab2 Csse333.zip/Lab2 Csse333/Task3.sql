USE NWindmorehask
Go
SELECT p.ProductID, p.ProductName, o.Quantity, o.UnitPrice, o.Discount, CEILING(o.UnitPrice*(1-o.Discount)) AS ActualPrice
FROM [Order Details] AS o, Products AS p
WHERE Quantity >= 100
ORDER BY o.Quantity ASC, p.ProductID ASC