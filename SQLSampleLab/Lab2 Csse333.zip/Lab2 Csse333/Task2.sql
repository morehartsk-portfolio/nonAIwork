USE NWindmorehask
Go
SELECT TOP 8 ProductID, ProductName, UnitsInStock, UnitPrice
FROM Products WHERE UnitsInStock < 20
ORDER BY UnitsInStock DESC