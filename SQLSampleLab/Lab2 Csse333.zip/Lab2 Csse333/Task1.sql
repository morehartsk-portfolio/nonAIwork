USE NWindmorehask
Go
SELECT ProductName, UnitsInStock
FROM Products WHERE UnitsOnOrder > 0