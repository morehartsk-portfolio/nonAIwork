using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DwarfMove : MonoBehaviour
{
    enum MoveType {Left, Right, Random, Seek, RunAway, Nap};//Seek, run, random when none apply
    Rigidbody2D body;
    CapsuleCollider2D _collider;
    [SerializeField] private MoveType _currentMoveType;
    public float speed = 0.5f;
    
    bool isNapping = false; // check if we are napping. if so, HALT ALL PROCESSES
    bool isInDanger = false;
    bool foundCabbage = false;
//check if there is danger or cabbage, else keep moving. if you see a cabbage
    // bool napTime = false;
    
    // Start is called before the first frame update
    void Start()//what if dwarves are constantly looking for player/cabbage
    {
    body = GetComponent<Rigidbody2D>();
    _collider = GetComponent<CapsuleCollider2D>();
    if(Random.Range(0f,1f) < 0.33f){
    _currentMoveType = MoveType.Left;
            }else if(Random.Range(0f,1f) < 0.66f){
    _currentMoveType = MoveType.Right;
            }else{
    _currentMoveType = MoveType.Random;//problem. nap should override all.
            }//choose random behavior
        
    }//now implement a way to detect at all times if there's something nearby, like, dunno...cabbages? Player? if detecting cabbage or player, player first, then cabbage
    //they can jump/fall off platforms in seek mode. random mode, they can also fall off, IF it's not the ground level.

    // Update is called once per frame
    void Update()
    {
        MoveType nextMoveType= _currentMoveType;
        //check for cabbages
        //check for player
        Debug.Log(_currentMoveType);
        //if either one, then change move type immediately.
        //otherwise, carry on as normal.
        switch(_currentMoveType){
            case MoveType.Left:
                nextMoveType = WanderLeft();
                break;
            case MoveType.Right:
                nextMoveType = WanderRight();
                break;
            case MoveType.Random:
                WanderRandom();
                nextMoveType = MoveType.Random;
                break;
            // nap should override all, but how should i transition between seek/run and normal corout?
            case MoveType.Seek://perhaps seek and run should not be coroutines because they could be constantly running
                SeekCabbage(); //we assume we're close enough to cabbage. seek for a second, then go back to rando.
                nextMoveType = MoveType.Random; //seek and run should not 
                break;//no movement happens in a coroutine
            case MoveType.RunAway://coroutine should determine move type and not move behavior because it can overlap.
            Debug.Log("RUN!");
                RunAway();
                nextMoveType = MoveType.Random; //seek and run should not 
                break;
        }
        
        isInDanger = PlayerSeek();
        foundCabbage = CabbageSeek(isInDanger);
        if(isInDanger && !isNapping){
                nextMoveType = MoveType.RunAway;
        }else{

        if(foundCabbage && !isNapping){
                nextMoveType = MoveType.Seek;
            
        }
        }
        _currentMoveType = nextMoveType;
        
    }


public void Nap(){
    StopCoroutine(WanderCoroutine(_currentMoveType));
    StopCoroutine(SeekCoroutine());
    StopCoroutine(RunAwayCoroutine());
//StopAllCoroutines();//this is very stupid
            Debug.LogFormat("Stopped all Coroutines: {0}", Time.time);
            isNapping = true;
    // Debug.Log("I ate a cabbage, now it's time to nap!");
    StartCoroutine(NapCoroutine());
        Debug.Log("done sleeping!");
        //isNapping = false;
        _currentMoveType = MoveType.Random;
}
       private IEnumerator NapCoroutine(){
        while(isNapping){
        yield return new WaitForSeconds(1.5f);
        isNapping = false;//change in here 
        }//now this works since we change the napping var properly.
    }//change how movement happens.


public float visionDistance = 1.5f;
public float jumpHeight = 0.5f;
private bool PlayerSeek(){
GameObject player = GameManager.Instance.GetPlayer();
if(player == null){
    return false;
}
float playerDistance = Vector3.Distance(transform.position, player.transform.position);
return (playerDistance <= visionDistance);

}//playerseek and cabbageseek are used to determine if should seek or not
private bool CabbageSeek(bool danger){
Vector3 cabbage = GameManager.Instance.GetNearestCabbagePosition(transform.position);
if(cabbage == default){
    return false;
}
float cabbageDistance = Vector3.Distance(transform.position, cabbage);
if(!danger){
if (cabbageDistance <= visionDistance){
    // _currentMoveType = MoveType.Seek;
    return true;
}
return false;
}else{
    // _currentMoveType = MoveType.RunAway;
return false;
}
}
private void SeekCabbage(){
    StopCoroutine(WanderCoroutine(_currentMoveType));
    StopCoroutine(RunAwayCoroutine());
    foundCabbage = true;
    // Debug.Log("I ate a cabbage, now it's time to nap!");
    StartCoroutine(SeekCoroutine());
        // Debug.Log("done sleeping!");
        //isNapping = false;
        _currentMoveType = MoveType.Random;
}
//change seek, nap, run to not be coroutines so as to not get confused.
private IEnumerator SeekCoroutine(){
    while(foundCabbage&& !isNapping){
        Seek();
        yield return null;
        foundCabbage = false;
    }
}
    private void Seek(){
        Vector3 cabbage = GameManager.Instance.GetNearestCabbagePosition(transform.position);
float cabbageDistance = Vector3.Distance(transform.position, cabbage);
//remember our assumption from above?
    
    Vector3 direction = transform.position - cabbage;
    Vector3 movement;
        
if(direction.x < 0){
        movement = Vector3.right;
    }else{
        movement = Vector3.left;
    }

    if(Mathf.Abs(direction.x) < 0.1f){
        movement.y = jumpHeight;
    }
    transform.Translate(movement * speed* Time.deltaTime);

foundCabbage = false;
    }
 private void RunFromDanger(){
    StopCoroutine(WanderCoroutine(_currentMoveType));
    StopCoroutine(SeekCoroutine());
    isInDanger = true;
    StartCoroutine(RunAwayCoroutine());
        Debug.Log("done Running!");
        _currentMoveType = MoveType.Random;

    }

 private IEnumerator RunAwayCoroutine(){
while(isInDanger&& !isNapping){
        RunAway();
        yield return null;
        isInDanger = false;
    }
 }
    private void RunAway(){
        GameObject player = GameManager.Instance.GetPlayer();
        if (player == null)
            return;
float playerDistance = Vector3.Distance(transform.position, player.transform.position);

    Vector3 direction = transform.position - player.transform.position;
    Vector3 movement;

        
if(direction.x < 0){
        movement = Vector3.right;
    }else{
        movement = Vector3.left;
    }

    if(Mathf.Abs(direction.x) < 0.1f){
        movement.y = jumpHeight;
    }

    transform.Translate(-movement * speed* Time.deltaTime);
      Vector3 pos = transform.position;
        if(pos.y < -5f){
            // Debug.Log("falling");
            pos.y = 5f;
            pos.x = 0f;
            transform.position = pos;
        _currentMoveType = MoveType.Random;

        }
        if(pos.x < -11f){
            pos.x = -11f;
            transform.position = pos;
            // Debug.Log("bump");
        _currentMoveType = MoveType.Right;
        }
        if(pos.x > 11f){
            pos.x = 11f;
            transform.position = pos;
            // Debug.Log("bump");
        _currentMoveType = MoveType.Left;
        }
        _currentMoveType = CheckEdge(MoveType.RunAway);
        isInDanger = false;
    }

    MoveType WanderLeft(){
        if(PlayerSeek()){
            return MoveType.RunAway;
        }
        if(CabbageSeek(false)){//if this executes, playerSeek returned false.
            return MoveType.Seek;
        }
        // Debug.Log("To the left");
        transform.Translate(Vector3.left * speed * Time.deltaTime);
        Vector3 pos = transform.position;
        if(pos.y < -5f){
            // Debug.Log("falling");
            pos.y = 5f;
            pos.x = 0f;
            transform.position = pos;
        _currentMoveType = MoveType.Random;

        }
        if(pos.x < -11f){
            pos.x = -11f;
            transform.position = pos;
            // Debug.Log("bump");
        _currentMoveType = MoveType.Right;
        }
        
        return CheckEdge(MoveType.Left);
    }
    MoveType WanderRight(){
        if(PlayerSeek()){
            return MoveType.RunAway;
        }
        if(CabbageSeek(false)){
            return MoveType.Seek;
        }
        // Debug.Log("To the right");
        transform.Translate(Vector3.right * speed * Time.deltaTime);
        Vector3 pos = transform.position;
        if(pos.y < -5f){
            Debug.Log("falling");
            pos.y = 5f;
            pos.x = 0f;
            transform.position = pos;
        _currentMoveType = MoveType.Random;
        }
        if(transform.position.x > 11f){
            pos.x = 11f;
            transform.position = pos;
            Debug.Log("bump");
        _currentMoveType = MoveType.Right;
        }
        
        return CheckEdge(MoveType.Right);
    }
    bool _finishedWander = true;
    private IEnumerator WanderCoroutine(MoveType direction)
    {
        float wanderTimer = 2f;
        _finishedWander = false;
        while (wanderTimer > 0 && !isNapping)//use a flag will help, since there is a loop inside of this coroutine and it won't easily break with StopAll
        {
 //   Debug.LogFormat("Am I napping? {0}", isNapping);
            if (direction == MoveType.Left)
                WanderLeft();
            else
                WanderRight();
            wanderTimer -= Time.deltaTime;
            yield return null; //instance of 
        }//infinite coroutines, sometimes they overlap.
        
        _finishedWander = true;//hypothetical global
    }


    void WanderRandom(){
        if(_finishedWander){
            if(Random.Range(0f,1f) < 0.5){
                StartCoroutine(WanderCoroutine(MoveType.Right));
            }else{
                StartCoroutine(WanderCoroutine(MoveType.Left));
            }
        }
    }

    MoveType CheckEdge(MoveType direction){
RaycastHit2D[] hits = new RaycastHit2D[1];//only hit one thing
float dir = 45f;
if(direction == MoveType.Left){
    dir = -45f;
}
    int rayHits = _collider.Raycast(Quaternion.Euler(0,0,dir)*Vector3.down, hits, 1.0f);

    if(rayHits == 0){
        if(direction == MoveType.Left)
            return MoveType.Right;
        
        return MoveType.Left;
        //add something here for if the X is less than a certain thing.
//we hit nothing
//at edge, now swap
//return direction to go
    }
        return direction;
    }
}
