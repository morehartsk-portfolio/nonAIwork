using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonLoader : MonoBehaviour
{
    public void LoadNextLevel()
    {
        GameManager.Instance.LoadNextLevel();
    }

    public void LoadTutorialLevel()
    {
        GameManager.Instance.LoadTutorial();
    }
    public void LoadMainMenu()
    {
        GameManager.Instance.LoadStartScene();
    }
}
