using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInfo : MonoBehaviour
{
    Rigidbody2D body;
    CapsuleCollider2D _collider;
    int dwarvesKilled = 0;
private void Awake(){
    body = GetComponent<Rigidbody2D>();
    _collider = GetComponent<CapsuleCollider2D>();
}
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public int GetKillCount(){
        return dwarvesKilled;
    }

     //https://stackoverflow.com/questions/68186905/how-to-detect-collision-between-moving-rigidbody-cube-and-static-empty-object
   private void OnCollisionEnter2D(Collision2D collision){
                // Debug.Log("A collision happened");
     string colliderInfo = collision.collider.tag; //get info on first collider
        //check if a collision actually occurred, then take the tags and compare!
        if(colliderInfo != null){
        // pinfo.Die();
        ContactPoint2D[] contactPoints = new ContactPoint2D[5];
        collision.GetContacts(contactPoints);
        // Debug.LogFormat("{0}", contactPoints[0].normal);

        if(contactPoints[0].normal.y != null){
            
                //Debug.Log(colliderInfo);
                if(colliderInfo == "Dwarf"){
                GameManager.Instance.HandleCollisionResults(0, gameObject, collision.gameObject); //each message has a diff result
                dwarvesKilled++;
                }
                if(colliderInfo == "Mushroom"){
                GameManager.Instance.HandleCollisionResults(2, gameObject, collision.gameObject); //each message has a diff result
                }
                
        }
        }
}

}
