using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CabbageManager : MonoBehaviour
{
    const int STARTING_CABBAGE_COUNT = 6;
    [SerializeField] int cabbageCount = STARTING_CABBAGE_COUNT;
    float[] possibleSpawnX = {0f, -3.5f, -7f, 3.5f, 7f, 4.5f, -4.5f};
    bool[] indexWasUsed = new bool[7];
    public float radius = 1f;
    public GameObject cabbagePrefab;
    List<GameObject> cabbages = new List<GameObject>();
    
    bool gameOver = false;
    // Start is called before the first frame update
    void Awake()
    {
        for(int i = 0; i < 7; i++){
            indexWasUsed[i] = false;
        }
        SpawnCabbages();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //spawn 
    //https://youtu.be/hViPCMZeQC4
    void SpawnCabbages(){
        for(int i = 0; i < STARTING_CABBAGE_COUNT; i++){//making locations more randomized
    //Random rand = new Random();
            // Debug.Log("We have arrived!");
        Vector3 randomPos = Random.insideUnitCircle * radius;
        GameObject c = Instantiate(cabbagePrefab, randomPos, Quaternion.identity);
        int xIndex = Random.Range(0,7);
        while(indexWasUsed[xIndex]){
            xIndex = Random.Range(0,7);
        }//Random.Range(-4.5f,4.5f)
                    c.transform.position = new Vector3(possibleSpawnX[xIndex], 0, 0);
                    indexWasUsed[xIndex] = true;
        cabbages.Add(c);
        }
    }



    public void ConsumeCabbage(GameObject cabbage){
        
        cabbageCount--;
        cabbages.Remove(cabbage);
        cabbage.GetComponent<CabbageInfo>().Die();
        Debug.Log(string.Format("{0} cabbages remaining.", cabbageCount));     
        if(cabbageCount == 0){
            gameOver = true;
            
        EventBus.Publish(EventBus.EventType.GameOver);
        }   
    }


    public Vector3 NearestCabbagePosition(Vector3 to){
        //https://gamedev.stackexchange.com/questions/202729/how-to-check-if-a-vector3-or-quaternion-are-unassigned
        //https://discussions.unity.com/t/how-do-you-check-for-a-vector3-null/4168/2
        //loop through cabbages, then pick one that's nearest to to
        Vector3 from = default;//in case if game over and we're still accessing this somehow
        if(!gameOver){

float minCabbageDistance = Vector3.Distance(to, cabbages[0].transform.position);
    from = cabbages[0].transform.position;
        foreach (GameObject c in cabbages){
            float currCabDist = Vector3.Distance(to, c.transform.position);
            if(currCabDist < minCabbageDistance){
                minCabbageDistance = currCabDist;
                from = c.transform.position;
             }
        }
        }
        return from;
    }


    public int GetCabbageCount(){
        return cabbageCount;
    }
}
