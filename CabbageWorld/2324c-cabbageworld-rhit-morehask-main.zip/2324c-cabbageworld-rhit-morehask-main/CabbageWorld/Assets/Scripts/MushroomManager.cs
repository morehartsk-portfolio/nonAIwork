using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MushroomManager : MonoBehaviour
{
    //can have multiple shrooms on screen. todo, implement auto-kill
    public float radius = 1f;
    public GameObject mushroomPrefab;
    List<GameObject> mushrooms = new List<GameObject>();
    // Start is called before the first frame update
    void Start()
    {
        
        // EventBus.Subscribe(EventBus.EventType.Tutorial, tutorial);//mushroom spawning tutorial
        // SpawnCabbages();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    //spawn 
    //https://youtu.be/hViPCMZeQC4
    public void SpawnShroom(){
        Vector3 randomPos = Random.insideUnitCircle * radius;
        GameObject m = Instantiate(mushroomPrefab, randomPos, Quaternion.identity);
        // GameObject m = Instantiate(mushroomPrefab, new Vector3(0,0,0), Quaternion.identity);
        mushrooms.Add(m);
        
    }



    public void ConsumeShroom(GameObject mushroom){
        mushrooms.Remove(mushroom);
        mushroom.GetComponent<MushroomInfo>().Die();
        
    }


}
