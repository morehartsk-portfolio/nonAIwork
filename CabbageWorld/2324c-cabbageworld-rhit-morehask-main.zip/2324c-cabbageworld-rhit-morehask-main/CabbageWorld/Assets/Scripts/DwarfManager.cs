using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DwarfManager : MonoBehaviour
{
    [SerializeField] GameObject dwarfPrefab;
    List<GameObject> dwarves = new List<GameObject>();
    [SerializeField] float cooldown = 2.5f;
    float maxSpeed = 0f;
    int numDwarves = 0;
    public int k = 5;//we have a number of dwarves initial. once all killed, send in next wave

    float timer;
    bool gameOver = false;
    
    // Start is called before the first frame update
    void Start()
    {
        EventBus.Subscribe(EventBus.EventType.GameOver, GameOver);
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        //track fastest object
         if(timer <= 0 && !gameOver){
             SpawnDwarves();
            
             timer = cooldown;            
         }
    }

    private void SpawnDwarves(){
        if(numDwarves < k && !gameOver){
            numDwarves++;
        GameObject newDwarf = Instantiate(dwarfPrefab);//vector3 is immutable, position is vector3
            newDwarf.transform.position = new Vector3(Random.Range(-5f,5f), 3, 0);
        dwarves.Add(newDwarf);
        
    }
    }

public void GameOver(){
    gameOver = true;//for checking cooldown timers and stuff
    //dwarves should now die.
    for(int i = 0; i < numDwarves; i++){
        Destroy(dwarves[i]); // just get rid of them, no need for fancy animations
    }
}
    
    public void KillDwarf(GameObject dwarf){
        numDwarves--;
        dwarves.Remove(dwarf);
        dwarf.GetComponent<DwarfInfo>().Die();
    }
}
