using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TextUpdate : MonoBehaviour
{
    enum Field { Tutorial, Pause, GameOver, Score};

    [SerializeField] Field field = Field.Tutorial;

    TMP_Text text;
    bool isTutorial = false;

    // Start is called before the first frame update
    void Start()
    {
        text = GetComponent<TMP_Text>();
        EventBus.Subscribe(EventBus.EventType.Pause, SetText);
        EventBus.Subscribe(EventBus.EventType.Resume, SetText);
        EventBus.Subscribe(EventBus.EventType.Tutorial, SetText);
        EventBus.Subscribe(EventBus.EventType.TutorialFinish, SetText);
        EventBus.Subscribe(EventBus.EventType.GameOver, SetText);
        SetText();

    }

    // Update is called once per frame
    void Update()
    {
        //SetText();

    }
    void SetText(){
        text.text = "";
        switch(field){
            case Field.Pause:
            if(GameManager.Instance.GetPaused()){
            text.text = "PAUSED!";
            }else{
                text.text = "";
            }
            break;
            case Field.Tutorial:
        text.text = "";
        Debug.LogFormat("This is our status RN:{0}",!GameManager.Instance.GetTutorial());
            if(!GameManager.Instance.GetTutorial()){
            text.text = "WASD/Arrows to move\nEsc/P to pause/resume\nZ to continue to main game\nmushrooms speed you up\nyou lose if dwarves eat all\nof your cabbages.";
            }else{
                text.text = "";
            }
            break;
            case Field.GameOver:
            text.text = "Game Over!\nScore: " + GameManager.Instance.Score.ToString();
            break;
        }
        
    }

}
