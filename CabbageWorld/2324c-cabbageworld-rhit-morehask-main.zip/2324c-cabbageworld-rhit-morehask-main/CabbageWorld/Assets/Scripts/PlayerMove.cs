using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    //rigidbody is a skeleton/hitbox
    Rigidbody2D body;
    CapsuleCollider2D _collider;
    float speed = 5f;
    float maxSpeed = 150f;
    public float jumpForce = 15f;
    public ForceMode2D jumpType = ForceMode2D.Impulse;
   public int jump = 0;
    // Start is called before the first frame update
private void Awake(){
    body = GetComponent<Rigidbody2D>();
    _collider = GetComponent<CapsuleCollider2D>();//event system needed for buttons to talk to each other. note for future.
}

    void Start()
    {
         //this
         
        EventBus.Subscribe(EventBus.EventType.GameOver, GameOverPlayer);
         //box collider is by default
    }

    // Update is called once per frame
    void Update()
    {
        //using input manager from project settings
        float deltaX = Input.GetAxis("Horizontal") * speed;
        Vector2 movement = new Vector2(deltaX, body.velocity.y);
        body.velocity = movement;
        
        bool grounded = false;
        Vector3 max = _collider.bounds.max;
        Vector3 min = _collider.bounds.min;
        //https://discussions.unity.com/t/cannot-modify-the-return-value-of-transform-position-because-its-not-a-variable/150330/3
        //for transformation and dealing with player going out of bounds.
    Vector3 pos = transform.position;

        Vector2 bottomRight = new Vector2(max.x, min.y-0.05f);
        Vector2 bottomLeft = new Vector2(min.x, min.y-0.05f);

        Debug.DrawLine(bottomLeft, bottomRight, Color.red);

        Collider2D hit = Physics2D.OverlapArea(bottomLeft, bottomRight);

        if(hit != null){
            grounded = true;
            jump = 0;
        }

        if((jump < 2 || grounded) && (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKeyDown(KeyCode.W))){
            body.AddForce(Vector2.up * jumpForce, jumpType);//how to register jumps
            jump++;
            
        // Debug.LogFormat("Jump count: {0}.", jump);
        }
            //this next bit handles falling out of bounds for player
        if(pos.y < -5f){
            pos.y = 5f;
            transform.position = pos;
        }
        if(pos.x > 11f){
            pos.x = 11f;
            transform.position = pos;
        }
        if(pos.x < -11f){
            pos.x = -11f;
            transform.position = pos;
        }
    }
    public void GameOverPlayer(){
        speed = 0;
        jumpForce = 0;
    }
public void SpeedChange(bool isIncrease, bool isShroom){ //to increase or decrease speed depending on events. shroom also affects speed
        if(isIncrease){
            if(speed < maxSpeed){
        if(isShroom){//i need to cap the speed lol
         speed *= 1.2f;   
        }else{
        speed *= 1.1f;
        }
            }else{
                speed = maxSpeed;
            }
        }else{
            speed *= (5f/6f);
        }
    }

//check if jump once already, then false
//check area to do an instant collision check
// OnCollisionEnter
}
