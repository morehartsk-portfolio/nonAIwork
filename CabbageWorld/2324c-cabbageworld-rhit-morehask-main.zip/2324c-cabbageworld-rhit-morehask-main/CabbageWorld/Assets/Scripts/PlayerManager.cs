using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerManager : MonoBehaviour
{
    [SerializeField] GameObject playerPrefab;
    GameObject _player = null;//if null, it vanishes
    // Start is called before the first frame update
    void Start()
    {
        
        EventBus.Subscribe(EventBus.EventType.GameOver, GameOver);
    }

    // Update is called once per frame
    void Update()
    {
        //check if player is dead, then respawn
        if(_player == null){
            _player = Instantiate(playerPrefab);
            _player.transform.position = new Vector3(5, 3, 0);
        }
        
    }

    
    public GameObject GetPlayer(){
        return _player;
    }
    //instead of wandering randomly, if it sees the player, there should be some fun stuff
    public void GameOver(){
        Debug.LogFormat("You have eaten {0} dwarves before they ate all your cabbages.", _player.GetComponent<PlayerInfo>().GetKillCount());
        // Destroy(_player);
    }
}
