using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIManager : MonoBehaviour
{
    [SerializeField] GameObject gameOverScreen;
    [SerializeField] GameObject tutorialScreen;



    // Start is called before the first frame update
    void Start()
    {
     
        GameManager.Instance.SetGameOverScreen(gameOverScreen);
        GameManager.Instance.SetTutorialScreen(tutorialScreen);

    }



}
