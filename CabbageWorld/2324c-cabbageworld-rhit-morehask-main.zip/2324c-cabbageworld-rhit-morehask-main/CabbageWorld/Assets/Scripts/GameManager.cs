using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : Singleton<GameManager>
{
    
    //check both update text and UI manager to make sure we're all on the same page actually
    string[] level = new[] { "SplashScreen", "Level1" };
    [SerializeField] int _sceneIndex = 0;
    [SerializeField] PlayerManager playerManager;
    [SerializeField] DwarfManager dwarfManager;
    [SerializeField] CabbageManager cabbageManager;
    [SerializeField] MushroomManager mushroomManager;
    bool paused = false;
    bool isInTutorial = false;
    int score = 0;
     public int Score { get => score;
        set {
            score = value;
        } }//game over coroutine will wait until button is pressed 
    // Start is called before the first frame update
    void Awake()
    {
        playerManager = FindObjectOfType<PlayerManager>();
        dwarfManager = FindObjectOfType<DwarfManager>();
        cabbageManager = FindObjectOfType<CabbageManager>();
        mushroomManager = FindObjectOfType<MushroomManager>();
        EventBus.Subscribe(EventBus.EventType.GameOver, GameOver);
        EventBus.Subscribe(EventBus.EventType.Tutorial, TutorialScene);

    }

    // Update is called once per frame
    void Update()
    {//check for pause! Also, signs, when run into, SHOULD pause the game. if 
    

        if(Input.GetKeyDown(KeyCode.P) || Input.GetKeyDown(KeyCode.Escape)){
            Debug.Log("paused");
            //this is from https://blog.gamedev.tv/how-to-basic-pause-system-in-unity/
            paused = !paused;
            if(paused){
            Time.timeScale = 0;
            EventBus.Publish(EventBus.EventType.Pause);
            }else{
            Time.timeScale = 1;
            EventBus.Publish(EventBus.EventType.Resume);
            }
//publish pause event
//if player collides with a sign, PUBLISH A PAUSE EVENT
        
    }

    if(Input.GetKeyDown(KeyCode.Z)){
        if(!isInTutorial){
            Time.timeScale = 1;
            EventBus.Publish(EventBus.EventType.TutorialFinish);
    }
    // else{
    //         Time.timeScale = 0;
    //         EventBus.Publish(EventBus.EventType.Tutorial);
    // }
        }
        //check cabbage counts
        //maybe i should check for an Ankh to revive...one cabbage. does not affect game over.
        //check for collision
        //check for everything else
    }

    GameObject tutorialScreen;
    public void SetTutorialScreen(GameObject go)
    {
        tutorialScreen = go;
        Debug.Log("REBEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEENGAAAAAAAAAAAAAA");
    }
    public void TutorialScene()
    {
        tutorialScreen.SetActive(true);
        
    //     // Reset();//reload everything to avoid between-game data leakage
     }
    
public GameObject GetPlayer(){
        return playerManager.GetPlayer();
    }
    public bool GetPaused(){
        return paused;
    }
    public bool GetTutorial(){
        return isInTutorial;
    }
public Vector3 GetNearestCabbagePosition(Vector3 to){
return cabbageManager.NearestCabbagePosition(to);
}
    public void LoadNextLevel()
    {

        SceneManager.LoadScene("Level1");
    } 
    public void LoadTutorial()
    {

        EventBus.Publish(EventBus.EventType.Tutorial);
        SceneManager.LoadScene("Level1");
            isInTutorial = true;
            Time.timeScale = 0;

            Debug.LogFormat("Am i in tutorial {0}", isInTutorial);
    }
    public void LoadStartScene(){
        
        SceneManager.LoadScene("SplashScreen");

    }

     GameObject gameOverScreen;
    public void SetGameOverScreen(GameObject go)
    {
        gameOverScreen = go;
    }
    public void GameOver()
    {
        gameOverScreen.SetActive(true);
        Reset();//reload everything to avoid between-game data leakage
    }

  
    public void Tutorial()
    {
            isInTutorial = true;
        
                Debug.Log("AAAAAAAAAAAAAAAAAAAAA");
            Time.timeScale = 0;
        // Reset();//reload everything to avoid between-game data leakage
    }

//types of collisions!
//0 = player collides with dwarf
//1 = dwarf consumes a cabbage
//2 = player consumes a shroom
    public void HandleCollisionResults(int colType, GameObject caller, GameObject callee){//caller is first object calling,
    // second object collided is callee
        switch(colType){
            case 0:
                Debug.LogFormat("Score: {0}", Score.ToString());
                caller.GetComponent<PlayerMove>().SpeedChange(true, false);
                dwarfManager.KillDwarf(callee);
                if(caller.GetComponent<PlayerInfo>().GetKillCount() % 5 == 0 && caller.GetComponent<PlayerInfo>().GetKillCount() > 0){
                    mushroomManager.SpawnShroom();
                }
                Score += 1;//inc score
                break; //
            case 1:
                //take a nap
                cabbageManager.ConsumeCabbage(callee);
                caller.GetComponent<DwarfMove>().Nap();
                if(cabbageManager.GetCabbageCount() == 0){
                    //initiate game over sequence
                    EventBus.Publish(EventBus.EventType.GameOver);
                }else{
                GameObject p = playerManager.GetPlayer();
                p.GetComponent<PlayerMove>().SpeedChange(false, false);
                }
                //since dwarf MUST consume cabbage, we're gonna do some other things instead i guess
                break;
                
            case 2:
                caller.GetComponent<PlayerMove>().SpeedChange(true, true);
                Score += 5;
                mushroomManager.ConsumeShroom(callee);
                break;

        }
    }
 void Reset(){
    Score = 0;
isInTutorial = false;
paused = false;
 }
 

}
