using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CabbageInfo : MonoBehaviour
{
    Rigidbody2D body;
    CircleCollider2D collider;
    private void Awake(){
    body = GetComponent<Rigidbody2D>();
    collider = GetComponent<CircleCollider2D>();
}
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void Die(){
        Destroy(gameObject);
    }
}
