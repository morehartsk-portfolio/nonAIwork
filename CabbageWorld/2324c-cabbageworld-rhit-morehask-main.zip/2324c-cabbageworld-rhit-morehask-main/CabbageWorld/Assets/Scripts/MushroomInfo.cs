using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MushroomInfo : MonoBehaviour
{
    
    Rigidbody2D body;
    CapsuleCollider2D _collider;
    // Start is called before the first frame update
    void Start()
    {
    body = GetComponent<Rigidbody2D>();
    _collider = GetComponent<CapsuleCollider2D>();
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void Die(){
        Destroy(gameObject);
    }
}
