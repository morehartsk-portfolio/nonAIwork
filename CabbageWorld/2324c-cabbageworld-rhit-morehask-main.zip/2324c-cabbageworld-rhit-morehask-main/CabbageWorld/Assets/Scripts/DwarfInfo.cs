using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DwarfInfo : MonoBehaviour
{//gameover movement will be in here since there's 
    // Start is called before the first frame update
    Rigidbody2D body;
    CapsuleCollider2D _collider;
    // PlayerInfo playerInfo;
    // CabbageManager manager;
    // GameManager gm;
    void Start()
    {
    body = GetComponent<Rigidbody2D>();
    _collider = GetComponent<CapsuleCollider2D>();
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
public void Die(){
        Destroy(gameObject);
    }

    
 
      //https://stackoverflow.com/questions/68186905/how-to-detect-collision-between-moving-rigidbody-cube-and-static-empty-object
   private void OnCollisionEnter2D(Collision2D collision){
     string colliderInfo = collision.collider.tag; //get info on first collider
     string otherColliderInfo = collision.otherCollider.tag; //get info on second collider
        //check if a collision actually occurred, then take the tags and compare!
        if(colliderInfo != null){
        // pinfo.Die();
        ContactPoint2D[] contactPoints = new ContactPoint2D[5];
        collision.GetContacts(contactPoints);
        // Debug.LogFormat("{0}", contactPoints[0].normal);

        if(contactPoints[0].normal.y != null){
            //nap should be entirely in here!
            //onHit component. when on hit, it takes args and then naps via method call
                if(colliderInfo == "Cabbage"){
                GameManager.Instance.HandleCollisionResults(1, gameObject, collision.gameObject); //each message has a diff result
                }
        }
        }
}
}
