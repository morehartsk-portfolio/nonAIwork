using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyManager : MonoBehaviour
{
    public int maxHP = 100000;
    public int currentHP = 0;
    [SerializeField] HealthSlider healthBar;
    // Start is called before the first frame update
    void Start()
    {
        currentHP = maxHP;
        healthBar.SetMaxHealth(maxHP);
        EventBus.Subscribe(EventBus.EventType.Attack, TakeDamage);
        EventBus.Subscribe(EventBus.EventType.UseSummon, TakeSummonDamage);
        EventBus.Subscribe(EventBus.EventType.CompanionAttack, TakeCompanionDamage);
    }


    // Update is called once per frame
    private void TakeDamage()
    {
        // currentHP -= (int)GameManager.Instance.GetPlayerAttack();
        currentHP -= PlayerManager.Instance.GetAttack();
        
        healthBar.SetHealth(currentHP);
        // Debug.LogFormat("Ouch! HP: {0}/{1}", currentHP, maxHP);
        // GameManager.Instance.LogAttack();
        if(currentHP <= 0){
            EventBus.Publish(EventBus.EventType.MonsterBeaten);
        }
    }  
     private void TakeCompanionDamage()
    {
        // currentHP -= (int)GameManager.Instance.GetPlayerAttack();
        currentHP -= StoreManager.Instance.companionLevel * 200;
        
        healthBar.SetHealth(currentHP);
        // Debug.LogFormat("Ouch! HP: {0}/{1}", currentHP, maxHP);
        // GameManager.Instance.LogAttack();
        if(currentHP <= 0){
            EventBus.Publish(EventBus.EventType.MonsterBeaten);
        }
    }
private void TakeSummonDamage()
    {
        // currentHP -= (int)GameManager.Instance.GetPlayerAttack();
        currentHP /= 2;
        
        healthBar.SetHealth(currentHP);
        // Debug.LogFormat("Ouch! HP: {0}/{1}", currentHP, maxHP);
        // GameManager.Instance.LogAttack();
        if(currentHP <= 0){
            EventBus.Publish(EventBus.EventType.MonsterBeaten);
        }
    }
    private void OnDestroy()
    {
        //this will avoid memory leaks in the EventBus, we probably have a few of those kicking around we need to clean up
        EventBus.Unsubscribe(EventBus.EventType.Attack, TakeDamage);
    }
}
