using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
//https://discussions.unity.com/t/how-to-find-time-in-milliseconds/36783
//https://www.youtube.com/watch?v=POq1i8FyRyQ

public class TimerText : MonoBehaviour
{
    [SerializeField] TMP_Text timer;
    float timeElapsed = 0.0f;
    // Start is called before the first frame update
    void Awake()
    {
        timer = GetComponent<TMP_Text>();
        timer.color = new Color(1,1,1,1);
    // float timeElapsed = 60.0f;
    //this is for the timer
    }

    // Update is called once per frame
    void Update()
    {
        // while(timeElapsed > 0.0f){
        timeElapsed  = GameManager.Instance.timeElapsed;
        int seconds = Mathf.FloorToInt((timeElapsed%60));
        int deciseconds = Mathf.FloorToInt((timeElapsed*10)%10);
        timer.text = string.Format("{0}.{1}", seconds, deciseconds);
        if(timeElapsed < 11.0f){
            timer.color = new Color(0.9811321f,0.5396219f,0.0407262f, 1);
        }
        if(timeElapsed < 4.0f){
            timer.color = new Color(1,0,0,1);
        }
        // }
       // timeElapsed = 0;
        if(timeElapsed <=0.0f){
            timer.text = "0.0";
        }
//timer.text = "0.0";
    }
}
