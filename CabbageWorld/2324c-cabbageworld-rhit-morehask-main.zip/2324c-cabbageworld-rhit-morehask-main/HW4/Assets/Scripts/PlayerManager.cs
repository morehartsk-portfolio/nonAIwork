using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerManager : Singleton<PlayerManager>
{
    [SerializeField] int gold = 0;
    [SerializeField] int basePlayerAttack = 10;//current attack
    [SerializeField] float attackMultiplier = 1.0f;
    bool hasUnlockedCompanions = false;
    bool hasUnlockedMagic = false;//magic is like how 
    float currencyMultiplier = 1.0f;
    int currentPlayerAttack = 10;
    // Start is called before the first frame update
    void Start()
    {
        EventBus.Subscribe(EventBus.EventType.Attack, EarnGold); 
        EventBus.Subscribe(EventBus.EventType.UseSummon, EarnGoldSummon); 
        EventBus.Subscribe(EventBus.EventType.CompanionAttack, EarnGoldCompanion);
        EventBus.Subscribe(EventBus.EventType.PurchaseAttackUpgrade, PurchaseAttack);
        EventBus.Subscribe(EventBus.EventType.PurchaseMagicUpgrade, PurchaseMagic);
        EventBus.Subscribe(EventBus.EventType.PurchaseSummon, PurchaseSummon);
        EventBus.Subscribe(EventBus.EventType.PurchaseCompanion, PurchaseCompanion);
        EventBus.Subscribe(EventBus.EventType.Reset, ResetStats);
    }

void SetAttack(){
    currentPlayerAttack = (int)(basePlayerAttack*attackMultiplier);    
    // Debug.LogFormat("Current base attack: {0}, current attack multiplier: {1}", basePlayerAttack, attackMultiplier);
}

public int GetAttack(){
    return currentPlayerAttack;
}
// public float GetPlayerAttackMult(){
// return attackMultiplier;
// }
// void UpgradeAttack(){
//     basePlayerAttack +=10;
//         currentPlayerAttack = basePlayerAttack*(int)attackMultiplier;
// }
// void UpgradeMagic(){
//     attackMultiplier += 0.5f;
//         currentPlayerAttack = basePlayerAttack*(int)attackMultiplier;
// }
    // Update is called once per frame
    void EarnGold()
    {
        gold += currentPlayerAttack;
    }
    void EarnGoldSummon()
    {
        gold += 25000;
    }
    void EarnGoldCompanion()
    {
        gold += StoreManager.Instance.companionLevel * 200;
    }
    public void PurchaseAttack(){
        gold -= StoreManager.Instance.GetATKUpgradePrice();
        basePlayerAttack += 10;
        SetAttack();
    }
    public void PurchaseMagic(){
        gold -= StoreManager.Instance.GetMAGUpgradePrice();
        attackMultiplier += 0.5f;
        SetAttack();
       }
    public void PurchaseSummon(){
        gold -= StoreManager.Instance.GetSummonPrice();
        // attackMultiplier += 0.5f;
        Debug.Log("Summon Bought");
        // SetAttack();
       }
    public void PurchaseCompanion(){
        gold -= StoreManager.Instance.GetCompanionPrice();
        // attackMultiplier += 0.5f;
        Debug.Log("Companion Bought");
        // SetAttack();
       }
    public int GetGold(){
        return gold;
    }
    public void ResetStats(){
        gold = 0;
        basePlayerAttack = 10;
        attackMultiplier = 1.0f;
        hasUnlockedCompanions = false;
        hasUnlockedMagic = false;
        currencyMultiplier = 1.0f;
        currentPlayerAttack = 10;
    }

}
