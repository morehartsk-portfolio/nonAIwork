using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class TextUpdate : MonoBehaviour
{
    enum Field { Gold, AttackLevel, MagicLevel, SummonLevel, CompanionLevel, PurchaseAttackButton, PurchaseMagicButton, PurchaseSummonButton, PurchaseCompanionButton};
    //0 is attack
    //1 is magic
    //2 is summon

    [SerializeField] Field field = Field.Gold;
    TMP_Text text;

    // Start is called before the first frame update
    void Start()
    {
        text = GetComponent<TMP_Text>();
        
        EventBus.Subscribe(EventBus.EventType.PurchaseAttackUpgrade, SetText);
        EventBus.Subscribe(EventBus.EventType.PurchaseMagicUpgrade, SetText);
        EventBus.Subscribe(EventBus.EventType.PurchaseSummon, SetText);
        EventBus.Subscribe(EventBus.EventType.PurchaseCompanion, SetText);
        EventBus.Subscribe(EventBus.EventType.UnlockSummon, SetText);
        EventBus.Subscribe(EventBus.EventType.MaxedATKUpgrade, SetText);
        EventBus.Subscribe(EventBus.EventType.MaxedMAGUpgrade, SetText);
        EventBus.Subscribe(EventBus.EventType.MaxedCompanions, SetText);
        EventBus.Subscribe(EventBus.EventType.TimeUp, SetText);//hmmm
        SetText();

    }

    // Update is called once per frame
    void Update()
    {
        //SetText();

    }

    void SetText()
    {
        if (field == Field.Gold)
        {
            text.text = "Gold: " + PlayerManager.Instance.GetGold().ToString();
            // text.text = "Gold: " + GameManager.Instance.ToString();
        }
          if (field == Field.AttackLevel)
        {
            if(StoreManager.Instance.isATKMaxed){
 text.text = "Attack (Lv. MAX): ";
            }else{
            text.text = "Attack (Lv. " + StoreManager.Instance.attackUpgradeLevel.ToString() + "): " + StoreManager.Instance.GetATKUpgradePrice().ToString();
            }
            // text.text = "Gold: " + GameManager.Instance.ToString();
        }
          if (field == Field.MagicLevel)
        {
            if(StoreManager.Instance.isMAGMaxed){
 text.text = "Magic (Lv. MAX): ";
            }else{

            text.text = "Magic(Lv. " + StoreManager.Instance.magicUpgradeLevel.ToString() + "): "+ StoreManager.Instance.GetMAGUpgradePrice().ToString();
            }
            // text.text = "Gold: " + GameManager.Instance.ToString();
        }
        
          if (field == Field.SummonLevel)
        {
            if(StoreManager.Instance.hasUnlockedSummon){
 text.text = "Summon (MAX): ";
            }else{

            text.text = "Summon: "+ StoreManager.Instance.GetSummonPrice().ToString();
            }
            // text.text = "Gold: " + GameManager.Instance.ToString();
        }  
        if (field == Field.CompanionLevel)
        {
            if(StoreManager.Instance.isCompanionMaxed){
 text.text = "Companion (MAX): ";
            }else{

            text.text = "Companion: "+ StoreManager.Instance.GetCompanionPrice().ToString();
            }
            // text.text = "Gold: " + GameManager.Instance.ToString();
        }
          if (field == Field.PurchaseAttackButton)
        {
            if(StoreManager.Instance.isATKMaxed){
 text.text = "SOLD OUT";
            }else{
            text.text = "BUY";
            }
        }
        if(field == Field.PurchaseMagicButton){
            if(StoreManager.Instance.isMAGMaxed){
 text.text = "SOLD OUT";
            }else{
            text.text = "BUY";
            }
            // text.text = "Gold: " + GameManager.Instance.ToString();
        }
        if(field == Field.PurchaseSummonButton){
            if(StoreManager.Instance.hasUnlockedSummon){
 text.text = "SOLD OUT";
            }else{
            text.text = "BUY";
            }
            // text.text = "Gold: " + GameManager.Instance.ToString();
        }
        if(field == Field.PurchaseCompanionButton){
            if(StoreManager.Instance.isCompanionMaxed){
 text.text = "SOLD OUT";
            }else{
            text.text = "BUY";
            }
            // text.text = "Gold: " + GameManager.Instance.ToString();
        }
    }

}
