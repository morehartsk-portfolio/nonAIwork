using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoreManager : Singleton<StoreManager>
{

    public int attackUpgradeLevel = 1;//max is 10
    public int magicUpgradeLevel = 0;//max is 5
    public int companionLevel = 0;
    int attackUpgradePrice = 250;//doubles
    int magicUpgradePrice = 1000;//1.5
    int summonPrice = 100;//one time
    int companionPrice = 50000;//3x purch, attacks per second
    public bool isATKMaxed = false;
    public bool isMAGMaxed = false;
    public bool hasUnlockedSummon = false;
    public bool isCompanionMaxed = false;
//     public int[,] storeItems = new int[5,5];
    //attack, magic, summon, companion
    // Start is called before the first frame update
    void Start()
    {
        
        EventBus.Subscribe(EventBus.EventType.PurchaseAttackUpgrade, UpdateAttack);
        EventBus.Subscribe(EventBus.EventType.PurchaseMagicUpgrade, UpdateMagic);
        EventBus.Subscribe(EventBus.EventType.PurchaseSummon, UpdateSummon);
        EventBus.Subscribe(EventBus.EventType.PurchaseCompanion, UpdateCompanion);
        EventBus.Subscribe(EventBus.EventType.Reset, Reset);


    }
    void UpdateAttack(){
        attackUpgradePrice += 500*(attackUpgradeLevel-1);
      attackUpgradeLevel++;  
      if(attackUpgradeLevel == 10){
        isATKMaxed = true;
        EventBus.Publish(EventBus.EventType.MaxedATKUpgrade);
      }
    }
    void UpdateMagic(){
        magicUpgradePrice += (int)(1000*(magicUpgradeLevel)*1.5f);
        magicUpgradeLevel++;
      if(magicUpgradeLevel == 5){
        isMAGMaxed = true;
        EventBus.Publish(EventBus.EventType.MaxedMAGUpgrade);
      }
    }
    void UpdateCompanion(){//companion price remains constant
        companionLevel++;
      if(companionLevel == 3){
        isCompanionMaxed = true;
        EventBus.Publish(EventBus.EventType.MaxedCompanions);
      }
    }

    void UpdateSummon(){
        hasUnlockedSummon = true;
        EventBus.Publish(EventBus.EventType.UnlockSummon);
    }
    public int GetATKUpgradePrice(){
        return attackUpgradePrice;
    }
    public int GetMAGUpgradePrice(){
        return magicUpgradePrice;
    }
    public int GetSummonPrice(){
        return summonPrice;
    }
    public int GetCompanionPrice(){
        return companionPrice;
    }


//     public void Buy(){
//         if(PlayerManager.Instance.GetGold() >= storeItems[2, ])
//     }

    
    public void Reset(){
    attackUpgradeLevel = 1;//max is 10
    magicUpgradeLevel = 0;//max is 5
    companionLevel = 0;
    attackUpgradePrice = 250;//doubles
    magicUpgradePrice = 1000;//
    summonPrice = 100;//one time, also changed to much lower num for demo purposes
    companionPrice = 50000;//3x purch, attacks per second
    isATKMaxed = false;
    isMAGMaxed = false;
    hasUnlockedSummon = false;
    isCompanionMaxed = false;
    }
}
