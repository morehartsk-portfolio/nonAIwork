using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SummonManager : MonoBehaviour
{
        [SerializeField] GameObject summon;
        [SerializeField] GameObject cooldown;
    // Start is called before the first frame 
    void Start()
    {
        //how to get to appear when purchased
        //should also sub to reset
        // EventBus.Subscribe(EventBus.EventType.UnlockSummon, ActivateSummon);
        EventBus.Subscribe(EventBus.EventType.UnlockSummon, SpawnSummon);
        EventBus.Subscribe(EventBus.EventType.UseSummon, UsedSummon);
        SpawnSummon();
        UsedSummon();
    }
//start corout if unlocked + used
    // Update is called once per frame
    void SpawnSummon()
    {
        summon.SetActive(false);
        if(GameManager.Instance.isInMain && StoreManager.Instance.hasUnlockedSummon){
            summon.SetActive(true);
            Debug.Log("Summon Unlocked!!!!");
        }
        
    }
    void UsedSummon(){
        cooldown.SetActive(false);
            if(GameManager.Instance.isInMain && GameManager.Instance.hasUsedSummon){
                cooldown.SetActive(true);
            }
        
        //start a coroutine here where it sliiiiiiiides down
    }
}
