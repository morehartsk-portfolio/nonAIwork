using System;
using UnityEngine;
using UnityEngine.Audio;
//https://youtu.be/6OT43pvUyfY //sound manager stuff was taken from a Brackey's tutorial

public class AudioManager : Singleton<AudioManager>
{
    public Sound[] sounds;

    // Start is called before the first frame update
    void Awake()
    {
        foreach(Sound s in sounds){
            s.source = gameObject.AddComponent<AudioSource>();
            s.source.clip = s.clip;

            s.source.volume = s.volume;
            s.source.pitch = s.pitch;
            // s.
        }
    }

    // Update is called once per frame
    public void Play(string name)
    {
        
// Debug.Log("Time Up!");
       Sound s = Array.Find(sounds, sound =>sound.name == name) ;//first find correct sound effect, then play
        // if(s == nu)
       s.source.Play();
    }
}
