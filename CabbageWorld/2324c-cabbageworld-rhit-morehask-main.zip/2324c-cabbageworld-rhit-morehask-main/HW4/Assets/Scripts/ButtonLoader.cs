using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonLoader : Singleton<ButtonLoader>
{//if unable to purchase, should also disable button
    enum Field {NormalButton, AttackButton, SummonButton, PurchaseAttackButton, PurchaseMagicButton, PurchaseSummonButton, PurchaseCompanionButton};
    bool shouldBeInteractable = true;
    [SerializeField] Field field = Field.NormalButton;
    void Awake(){
    if(field == Field.AttackButton){
        shouldBeInteractable = true;
    }
        gameObject.GetComponent<Button>().interactable = shouldBeInteractable;
        EventBus.Subscribe(EventBus.EventType.MaxedATKUpgrade, DisableButton);
        EventBus.Subscribe(EventBus.EventType.MaxedCompanions, DisableButton);
        EventBus.Subscribe(EventBus.EventType.MaxedMAGUpgrade, DisableButton);
        EventBus.Subscribe(EventBus.EventType.UnlockSummon, DisableButton);
        EventBus.Subscribe(EventBus.EventType.TimeUp, DisableButton);
    }
    void Update(){
        if(field == Field.PurchaseAttackButton && PlayerManager.Instance.GetGold() < StoreManager.Instance.GetATKUpgradePrice()){
    // Debug.LogFormat("I am die, thank you forever!{0}", shouldBeInteractable);
        shouldBeInteractable = false;
        }
        if(field == Field.PurchaseMagicButton && PlayerManager.Instance.GetGold() < StoreManager.Instance.GetMAGUpgradePrice()){
            // Debug.LogFormat("I am die, thank you forever!{0}", shouldBeInteractable);
        shouldBeInteractable = false;
        }
        if(field == Field.PurchaseCompanionButton && PlayerManager.Instance.GetGold() < StoreManager.Instance.GetCompanionPrice()){
            // Debug.LogFormat("I am die, thank you forever!{0}", shouldBeInteractable);
        shouldBeInteractable = false;
        }
        if(field == Field.PurchaseSummonButton && PlayerManager.Instance.GetGold() < StoreManager.Instance.GetSummonPrice()){
            // Debug.LogFormat("I am die, thank you forever!{0}", shouldBeInteractable);
        shouldBeInteractable = false;
        }
        
        if((field == Field.PurchaseAttackButton && StoreManager.Instance.isATKMaxed) ||
        (field == Field.PurchaseSummonButton && StoreManager.Instance.hasUnlockedSummon) || (field == Field.PurchaseMagicButton && StoreManager.Instance.isMAGMaxed)
         || (field == Field.PurchaseCompanionButton && StoreManager.Instance.isCompanionMaxed)){
            // Debug.Log("I am die, thank you forever!");
        
        shouldBeInteractable = false;
        }
        
        gameObject.GetComponent<Button>().interactable = shouldBeInteractable;
    }
    public void LoadMainLevel()
    {
        GameManager.Instance.LoadMainLevel();
    }
    public void LoadTitleScreen()
    {
        GameManager.Instance.LoadTitleScreen();
    }
    public void AttackEnemy(){
        if(StoreManager.Instance.attackUpgradeLevel < 3){//determine which of sounds to play
        AudioManager.Instance.Play("AttackLowLV");
        }else if(StoreManager.Instance.attackUpgradeLevel < 9){
        AudioManager.Instance.Play("AttackMedLV");
        }else{
        AudioManager.Instance.Play("AttackHiLV");
        }
        EventBus.Publish(EventBus.EventType.Attack);
    }
    public void BuyAttackUpgrade(){
        if(PlayerManager.Instance.GetGold() >= StoreManager.Instance.GetATKUpgradePrice()){
        EventBus.Publish(EventBus.EventType.PurchaseAttackUpgrade);
        }
    }
    public void BuyMagicUpgrade(){
        if(PlayerManager.Instance.GetGold() >= StoreManager.Instance.GetMAGUpgradePrice()){
        EventBus.Publish(EventBus.EventType.PurchaseMagicUpgrade);
        }
    }
    public void BuySummon(){
        if(PlayerManager.Instance.GetGold() >= StoreManager.Instance.GetSummonPrice()){
        EventBus.Publish(EventBus.EventType.PurchaseSummon);
        }
    }
    public void BuyCompanion(){
        if(PlayerManager.Instance.GetGold() >= StoreManager.Instance.GetCompanionPrice()){
        EventBus.Publish(EventBus.EventType.PurchaseCompanion);
        }
    }
    public void DisableButton(){//I really need to work on event bus stuff to you know what...
        // if(((field == Field.PurchaseAttackButton && StoreManager.Instance.IsMaxedOutAttackUpgrades()) || (field == Field.PurchaseMagicButton && StoreManager.Instance.IsMaxedOutMagicUpgrades()))
        // ||(field == Field.AttackButton)){
        // }
        if((field == Field.PurchaseAttackButton && StoreManager.Instance.isATKMaxed) || (field == Field.PurchaseMagicButton && StoreManager.Instance.isMAGMaxed)
        ||(field == Field.PurchaseSummonButton && StoreManager.Instance.hasUnlockedSummon) || (field == Field.PurchaseCompanionButton && StoreManager.Instance.isCompanionMaxed)
         || field == Field.AttackButton){
            // Debug.Log("I am die, thank you forever!");
        gameObject.GetComponent<Button>().interactable = false;
        
        shouldBeInteractable = false;
        }
    }

    
    
}