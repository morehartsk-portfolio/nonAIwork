using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class StoreItem : MonoBehaviour
{
    //https://youtu.be/Oie-G5xuQNA what i used for reference
    // Start is called before the first frame update
    public int itemID;//0 = attack, 1 = mag, 2 = summon, 3 = companion
    public int price;
    public int level;//max level for each atk = 10, mag = 5, summon = 1, companion = 3
    //price rates will differ
    //depending on field, price will change differently as well.
    //idk store manaer???
    void Start()
    {
        
    }

    // Update is called once per frame
    public void Purchased()
    {
        
    }
}
