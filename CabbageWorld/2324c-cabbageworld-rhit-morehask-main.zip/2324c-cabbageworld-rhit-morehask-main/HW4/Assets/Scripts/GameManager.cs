using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : Singleton<GameManager>
{
    // [SerializeField] GameObject playerPrefab;
    // GameObject _player = null;
    // [SerializeField] int lives = 3;
    //https://discussions.unity.com/t/how-do-i-get-the-name-of-the-active-scene/158229
    //Source of audio: me.
    public float timeElapsed = 0.0f;
    public float maxTime = 60.0f;
    public bool isInMain = false;
    public bool ending2Unlocked = false;
    public bool hasUnlockedSummon = false;
    public bool hasUsedSummon = false;
    //upgrade base attack
    //add magic
    //
//player ATK will contribute to moneys
    Scene m_Scene;
 string sceneName;

    string[] level = new[] { "SplashScreen", "MainScene", "StoreScene", "Ending" };
    [SerializeField] int _sceneIndex = 0;


    // Start is called before the first frame update
    void Awake()
    {
        // SpawnPlayer();
        timeElapsed = maxTime;
        m_Scene = SceneManager.GetActiveScene();
        sceneName = m_Scene.name;
        if(sceneName == "MainScene"){
            isInMain = true;
            if(StoreManager.Instance.companionLevel > 0){
            StartCoroutine(CompanionAttackCoroutine());
            }
        }

        EventBus.Subscribe(EventBus.EventType.MonsterBeaten, GameWon);
    }

    // Update is called once per frame
    void Update()
    {
        if(isInMain){
        timeElapsed -= Time.deltaTime;
        if(Input.GetKeyDown(KeyCode.Q) && StoreManager.Instance.hasUnlockedSummon && !hasUsedSummon && timeElapsed > 0.0f){
            hasUsedSummon = true;
        EventBus.Publish(EventBus.EventType.UseSummon);
        }
        if(timeElapsed<=0.0f){
            // timeElapsed = 0.0f;
        EventBus.Publish(EventBus.EventType.TimeUp);
            StartCoroutine(GameOverCoroutine());
            isInMain = false;
            hasUsedSummon = false;
        }
        // Debug.Log("Am in main");
        }
        //doesnt respawn player anymore, that happens only when PlayerDeath is called
    }

  

public void LoadMainLevel(){
        SceneManager.LoadScene("MainScene");
        isInMain = true;
        
        // StartCoroutine(SpawnPlayerCoroutine());
}
public void LoadTitleScreen(){
        SceneManager.LoadScene("SplashScreen");
        
        // isInMain = false;
        Reset();//reload everything to avoid between-game data leakage

        // StartCoroutine(SpawnPlayerCoroutine());
}
public void GameWon(){
        isInMain = false;
        StopAllCoroutines();
        StartCoroutine(GameWonCoroutine());
}
    IEnumerator GameWonCoroutine()
    {
        // gameOverScreen.SetActive(true);
        // AudioManager.Instance.Play("TimeUp");
        yield return new WaitForSeconds(1f);
        SceneManager.LoadScene("Ending");
        isInMain = false;
    }
    IEnumerator GameOverCoroutine()
    {
        // gameOverScreen.SetActive(true);
        AudioManager.Instance.Play("TimeUp");
        yield return new WaitForSeconds(1f);
        SceneManager.LoadScene("StoreScene");
        isInMain = false;
        // Reset();//reload everything to avoid between-game data leakage
    }

 IEnumerator CompanionAttackCoroutine()
    {
        while (isInMain)
        {
        EventBus.Publish(EventBus.EventType.CompanionAttack);
        yield return new WaitForSeconds(1f);
        }
    }
    private void Reset()
    {
        timeElapsed = maxTime;
        EventBus.Publish(EventBus.EventType.Reset);
        //loading points
        // Points = 0;
        // Lives = 3;
        //we have a problem with the player being missing when we start for the second time now....
    }
}
